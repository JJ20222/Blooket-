**Discord server: https://discord.gg/K5xUbuDqmG**

# Blooket-Hack
All of the cheats are based on a game mode.


# How to run

note: **TURN YOUR AD BLOCKER OFF OR IT WON'T WORK!**

Open console and paste this: 
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/main.js")
.then((res) => res.text()
.then((t) => eval(t)))
```

# Video Tutorial
https://user-images.githubusercontent.com/73669084/137641316-ad4f1cbb-0f3d-46e2-83a7-74b7e8b9dd3c.mp4


# Bookmarklet tutorial:
https://streamable.com/t4u7i7

1. Make a bookmark (the star on the right side of the url bar if you are using chrome)
2. Click on more at the bottom left corner
3. Delete everything in the url box
4. Type `javascript:`
5. Paste in the code
