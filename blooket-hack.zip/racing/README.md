# racing 

This cheat only works in racing game mode!

# instantWin.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/racing/instantWin.js").then((res) => res.text().then((t) => eval(t)))
```
